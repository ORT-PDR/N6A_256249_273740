﻿using System;
namespace Server
{
	public static class ServerConfig
	{
        public static string serverIPconfigkey = "ServerIpAddress";
        public static string serverPortconfigkey = "ServerPort";
    }
}

