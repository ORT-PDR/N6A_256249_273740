﻿using System;
namespace Client
{
	public static class ClientConfig
	{
        public static string serverIPconfigkey = "ServerIpAddress";
        public static string serverPortconfigkey = "ServerPort";
        public static string clientIPconfigkey = "ClientIpAddress";
    }
}

