using System;
using System.Linq;
using Server.BusinessLogic;
using Communication;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;
using System.Xml.Linq;
using System.Runtime.InteropServices;
using Communication.FileHandlers;

namespace Client.UI
{
    public class ProductMenu
    {
        private ConversionHandler conversionHandler;
        private NetworkDataHelper networkDataHelper;
        private string user;
        private TcpClient tcpClient;

        public ProductMenu(TcpClient _tcpClient)
        {
            conversionHandler = new ConversionHandler();
            networkDataHelper = new NetworkDataHelper(_tcpClient);
            tcpClient = _tcpClient;
        }

        public async Task ShowMainMenu(string _user)
        {
            Console.Clear();
            while (true)
            {
                user = _user;
                
                Console.WriteLine("Product Menu:");
                Console.WriteLine("1. Publish Product");
                Console.WriteLine("2. Update Product");
                Console.WriteLine("3. Delete Product");
                Console.WriteLine("4. View Products");
                Console.WriteLine("5. My Purchases");
                Console.WriteLine("6. Exit");
                

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        await PublishProduct();
                        break;
                    case "2":
                        await UpdateProduct();
                        break;
                    case "3":
                        await DeleteProduct();
                        break;
                    case "4":
                        await ViewProductsMenu();
                        break;
                    case "5":
                        await ViewPurchases();
                        break;
                    case "6":
                        Console.WriteLine("Logging out...");
                        await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.Logout));
                        tcpClient.Close();
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        private async Task PublishProduct()
        {
            Console.Clear();
            Console.WriteLine("Enter product details:");

            Console.WriteLine("Name: ");
            string? name = Console.ReadLine();
            Console.WriteLine("Description: ");
            string? description = Console.ReadLine();
            Console.WriteLine("Price: ");
            string? price = Console.ReadLine();
            Console.WriteLine("Stock available: ");
            string ? stock = Console.ReadLine();
            Console.WriteLine("Absolute path of the product picture: ");
            String imageAbsPath = Console.ReadLine();

            try
            {
                await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.PublishProduct));

                if (imageAbsPath != null)
                {
                    var fileCommonHandler = new FileCommsHandler(networkDataHelper);
                    await fileCommonHandler.SendFile(imageAbsPath);
                }

                string data = $"{name}#{description}#{price}#{stock}#{user}";
                await Send(data);

                byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
                byte[] responseBytes = await networkDataHelper.ReceiveAsync(dataLength);
                string response = conversionHandler.ConvertBytesToString(responseBytes);

                if (response == "Success")
                {
                    Console.WriteLine("Product published successfully.");
                    System.Console.WriteLine("Press any key to continue");
                    System.Console.ReadKey();
                    Console.Clear();
                }
                else
                {
                    Console.WriteLine(response);
                    System.Console.WriteLine("Press any key to continue");
                    System.Console.ReadKey();
                    Console.Clear();
                }
            }
            catch (SocketException)
            {
                Console.Clear();
                Console.WriteLine("Server disconnected");
            }
            catch(FormatException formatEx)
            {
                Console.WriteLine("Format exception. Stock and price must be integer.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected Exception: " + ex.Message);
            }
        }

        private async Task UpdateProduct()
        {
            Console.Clear();
            var userProducts = await RetrieveAllUserProducts();

            byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
            int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
            byte[] listBytes = await networkDataHelper.ReceiveAsync(dataLength);
            string response = conversionHandler.ConvertBytesToString(listBytes);

            if (response == "Success")
            {
                if (userProducts.Length > 0)
                {
                    Console.WriteLine("Select a product to update:");
                    for (int i = 0; i < userProducts.Length; i++)
                    {
                        string[] data = userProducts[i].Split("#");
                        Console.WriteLine($"{i + 1}. Name: {data[0]} | Description: {data[1]} | Stock: {data[2]} | Price: {data[3]}");
                    }

                    if (int.TryParse(Console.ReadLine(), out int selectedIndex) && selectedIndex >= 1 && selectedIndex <= userProducts.Length)
                    {
                        await ModifyProductMenu(userProducts[selectedIndex - 1]);
                    }
                    else
                    {
                        Console.WriteLine("Invalid selection.");
                    }
                }
                else
                {
                    Console.WriteLine("You have no products to update.");
                }
            }
            else
            {
                Console.WriteLine(response);
            }
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
        }

        private async Task<string[]> RetrieveAllUserProducts()
        {
            try
            {
                await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.GetAllUserProducts));
                await Send(user);

                byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
                byte[] listBytes = await networkDataHelper.ReceiveAsync(dataLength);
                string list = conversionHandler.ConvertBytesToString(listBytes);
                string[] products = list.Split(";");
                return products;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return new string[0];
        }
        
        private async Task<string[]> RetrieveAllProducts()
        {
            try
            {
                await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.GetAllProducts));
                await Send(user);

                byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
                byte[] listBytes = await networkDataHelper.ReceiveAsync(dataLength);
                string list = conversionHandler.ConvertBytesToString(listBytes);
                string[] products = list.Split(";");
                return products;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return new string[0];
        }

        private async Task ModifyProductMenu(string selectedProduct)
        {
            Console.Clear();
            bool back = false;
            
            string[] product = selectedProduct.Split("#");

            while (!back)
            {
                Console.WriteLine("Select an attribute to update:");
                Console.WriteLine("1. Description");
                Console.WriteLine("2. Stock Available");
                Console.WriteLine("3. Price");
                Console.WriteLine("4. Image Path");
                Console.WriteLine("5. Done (Back)");
                
                string userInput = Console.ReadLine();

                if (userInput.Equals("back", StringComparison.OrdinalIgnoreCase))
                {
                    back = true;
                    break;
                }

                if (int.TryParse(userInput, out int attributeChoice) && attributeChoice >= 1 && attributeChoice <= 5)
                {
                    string newValue = string.Empty;

                    switch (attributeChoice)
                    {
                        case 1:
                            Console.Clear();
                            Console.WriteLine($"Description (current: {product[1]}): ");
                            Console.WriteLine("Enter new description or BACK to go back");
                            newValue = Console.ReadLine();
                            await SendModifiedValue(product[0], "description", newValue);
                            break;
                        case 2:
                            Console.Clear();
                            Console.WriteLine($"Stock Available (current: {product[2]}): ");
                            if (int.TryParse(Console.ReadLine(), out int newStock) && newStock >= 0)
                            {
                                await SendModifiedValue(product[0], "stock", newStock.ToString());
                            }
                            else
                            {
                                Console.WriteLine("Invalid stock value. Stock must be a non-negative number.");
                            }
                            break;
                        case 3:
                            Console.Clear();
                            Console.WriteLine($"Price (current: {product[3]}): ");
                            if (double.TryParse(Console.ReadLine(), out double newPrice) && newPrice > 0)
                            {
                                await SendModifiedValue(product[0], "price", newPrice.ToString());
                            }
                            else
                            {
                                Console.WriteLine("Invalid price value. Price must be a positive number.");
                            }
                            break;
                        case 4:
                            Console.Clear();
                            Console.WriteLine($"Image Path (current: {product[4]}): ");
                            newValue = Console.ReadLine();
                            product[4] = !string.IsNullOrWhiteSpace(newValue) ? newValue : product[4];
                            await SendModifiedValue(product[0], "image", newValue);
                            break;
                        case 5:
                            back = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid attribute selection. Please select a valid option (1-5) or type 'back' to quit.");
                }
            }
        }

        private async Task SendModifiedValue(string productName, string attribute, string newValue)
        {
            try
            {
                if (attribute == "image")
                {
                    await SendNewImage(productName, newValue);
                }

                else
                {
                    await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.UpdateProduct));

                    string data = $"{productName}#{attribute}#{newValue}#{user}";

                    await Send(data);
                }

                byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
                byte[] responseBytes = await networkDataHelper.ReceiveAsync(dataLength);
                string response = conversionHandler.ConvertBytesToString(responseBytes);

                if (response == "Success")
                {
                    Console.WriteLine("Product updated successfully.");
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Product updated error.");
                }
            }
            catch (SocketException)
            {
                Console.Clear();
                Console.WriteLine("Server disconnected");
                Console.ReadKey();
            }
            catch (FormatException formatEx)
            {
                Console.WriteLine("Format exception. Stock and price must be integer.");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected Exception: " + ex.Message);
                Console.ReadKey();
            }
        }

        private async Task SendNewImage(string productName, string newImagePath)
        {
            try
            {
                await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.UpdateProductImage));
                var fileCommonHandler = new FileCommsHandler(networkDataHelper);
                await fileCommonHandler.SendFile(newImagePath);
                await Send($"{productName}#{user}");
            }
            catch (SocketException)
            {
                Console.Clear();
                Console.WriteLine("Server disconnected");
                Console.ReadKey();
            }
            catch (FormatException formatEx)
            {
                Console.WriteLine("Format exception. Stock and price must be integer.");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected Exception: " + ex.Message);
                Console.ReadKey();
            }
        }

        private async Task DeleteProduct()
        {
            Console.Clear();
            var userProducts = await RetrieveAllUserProducts();

            byte[] lenBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
            int responseLength = conversionHandler.ConvertBytesToInt(lenBytes);
            byte[] resBytes = await networkDataHelper.ReceiveAsync(responseLength);
            string res = conversionHandler.ConvertBytesToString(resBytes);

            if (res == "Success")
            {
                if (!userProducts.All(string.IsNullOrEmpty) && userProducts.Length > 0)
                {
                    Console.WriteLine("Select a product to delete:");
                    for (int i = 0; i < userProducts.Length; i++)
                    {
                        string[] data = userProducts[i].Split("#");
                        Console.WriteLine(
                            $"{i + 1}. Name: {data[0]} | Description: {data[1]} | Stock: {data[2]} | Price: {data[3]}");
                    }

                    var selectedProduct = Console.ReadLine();

                    if (int.TryParse(selectedProduct, out int selectedIndex) && selectedIndex >= 1 &&
                        selectedIndex <= userProducts.Length)
                    {
                        Console.WriteLine($"Are you sure you want to delete this product? (yes/no)");

                        string confirmation = Console.ReadLine();
                        if (confirmation.Equals("yes", StringComparison.OrdinalIgnoreCase))
                        {
                            await networkDataHelper.SendAsync(
                                conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.DeleteProduct));
                            await Send(userProducts[selectedIndex - 1].Split("#")[0] + "#" + user);

                            byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                            int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
                            byte[] responseBytes = await networkDataHelper.ReceiveAsync(dataLength);
                            string response = conversionHandler.ConvertBytesToString(responseBytes);

                            if (response == "Success")
                            {
                                Console.WriteLine("Product deleted successfully.");
                            }
                            else
                            {
                                Console.WriteLine(response);
                                Console.WriteLine("Press any key to continue");
                                Console.ReadKey();
                            }
                        }
                        else
                        {
                            Console.WriteLine("Product not deleted.");
                        }
                    }
                    else
                    {
                        Console.WriteLine(
                            "Invalid selection. Please select a valid product number or type 'back' to quit.");
                    }
                }
                else
                {
                    Console.WriteLine("You have no products to delete.");
                }
            }
        }

        private async Task ViewProductsMenu()
        {
            Console.Clear();
            var products = await RetrieveAllProducts();

            byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
            int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
            byte[] responseBytes = await networkDataHelper.ReceiveAsync(dataLength);
            string response = conversionHandler.ConvertBytesToString(responseBytes);

            if (response == "Success")
            {
                if (!products.All(string.IsNullOrEmpty) && products.Length > 0)
                {
                    Console.WriteLine("If you want to search a product, type the name of the product, else select a product to expand");
                    for (int i = 0; i < products.Length; i++)
                    {
                        string[] data = products[i].Split("#");
                        Console.WriteLine(
                            $"{i + 1}. Name: {data[0]} | Description: {data[1]} | Stock: {data[2]} | Price: {data[3]}");
                    }
                    var option = Console.ReadLine();

                    if (int.TryParse(option, out int selectedIndex) && selectedIndex >= 1 &&
                        selectedIndex <= products.Length)
                    {
                        var product = products[selectedIndex - 1].Split("#");
                        await ViewProduct(product);
                    }
                    else
                    {
                        await SearchProducts(option);
                    }
                }
                else
                {
                    Console.WriteLine("You have no products to view.");
                }
            }
            else
            {
                Console.WriteLine(response);
                Console.WriteLine("Press any key to continue");
                Console.ReadKey();
            }
        }
        
        private async Task ViewProduct(string[] product)
        {
            Console.Clear();
            Console.WriteLine($"Name: {product[0]}");
            Console.WriteLine($"Description: {product[1]}");
            Console.WriteLine($"Stock: {product[2]}");
            Console.WriteLine($"Price: {product[3]}");
            Console.WriteLine($"Image Path: {product[4]}");
            Console.WriteLine($"Owner: {product[5]}");
            Console.WriteLine("----Menu----");
            Console.WriteLine("1. Buy Product");
            Console.WriteLine("2. Add Review");
            Console.WriteLine("3. Explore Reviews");
            Console.WriteLine("4. Download Product Image");
            Console.WriteLine("5. Exit");

            bool exit = false;
            while (!exit)
            {
                var userInput = Console.ReadLine();
                if (int.TryParse(userInput, out int attributeChoice) && attributeChoice >= 1 && attributeChoice <= 5)
                {
                    switch (attributeChoice)
                    {
                        case 1:
                            await BuyProduct(product);
                            break;
                        case 2:
                            await ReviewProduct(product);
                            break;
                        case 3:
                            await ExploreReviews(product);
                            break;
                        case 4:
                            await DownloadImage(product);
                            break;
                        case 5:
                            return;
                    }
                    exit = true;
                }
                else
                {
                    if (userInput == "exit")
                    {
                        return;
                    }
                    Console.WriteLine("Invalid attribute selection. Please select a valid option (1-5) or type 'exit' to quit.");
                }
            }
        }

        private async Task BuyProduct(string[] product)
        {
            if (int.Parse(product[2]) <= 0)
            {
                Console.WriteLine("Product out of stock");
                return;
            }
            if (product[5] == user)
            {
                Console.WriteLine("ERROR: You can't buy your product");
                return;
            }
            
            Console.WriteLine($"Are you sure you want to Buy this product for {product[3]}$? (yes/no)");

            string confirmation = Console.ReadLine();
            if (confirmation.Equals("yes", StringComparison.OrdinalIgnoreCase))
            {
                await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.BuyProduct));
                await Send(product[0]+"#"+product[5]+"#"+user);
                            
                byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
                byte[] responseBytes = await networkDataHelper.ReceiveAsync(dataLength);
                string response = conversionHandler.ConvertBytesToString(responseBytes);

                if (response == "Success")
                {
                    Console.WriteLine("Product bought successfully.");
                }
                else
                {
                    Console.WriteLine(response);
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                }
            }
            else
            {
                Console.WriteLine("Product not bought.");
            }
        }

        private async Task ViewPurchases()
        {
            Console.Clear();
            var products = await RetrieveAllPurchases();


            byte[] lb = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
            int dl = conversionHandler.ConvertBytesToInt(lb);
            byte[] responseBytes = await networkDataHelper.ReceiveAsync(dl);
            string response = conversionHandler.ConvertBytesToString(responseBytes);

            if (response == "Success")
            {

                if (!products.All(string.IsNullOrEmpty) && products.Length > 0)
                {
                    Console.WriteLine("Select a product to expand:");

                    bool exit = false;
                    while (!exit)
                    {
                        for (int i = 0; i < products.Length; i++)
                        {
                            string[] data = products[i].Split("#");
                            Console.WriteLine(
                                $"{i + 1}. Name: {data[0]} | Bought for: {data[3]}");
                        }

                        var option = Console.ReadLine();

                        if (int.TryParse(option, out int selectedIndex) && selectedIndex >= 1 &&
                            selectedIndex <= products.Length)
                        {
                            var product = products[selectedIndex - 1].Split("#");
                            await ViewProduct(product);
                            return;
                        }
                        else if (option == "exit")
                        {
                            return;
                        }
                        else
                        {
                            Console.WriteLine("Invalid selection. Please select a valid product number or type 'exit' to quit.");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("You have no products to view.");
                }
            }
            else
            {
                Console.WriteLine(response);
                Console.WriteLine("Press any key to continue");
                Console.ReadKey();
            }
        }

        private async Task DownloadImage(string[] product)
        {
            await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.DownloadProductImage));
            await Send(product[4]);

            byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
            int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
            byte[] responseBytes = await networkDataHelper.ReceiveAsync(dataLength);
            string response = conversionHandler.ConvertBytesToString(responseBytes);

            if (response == "Success")
            {
                Console.WriteLine("Image has been downloaded to your Downloads folder.");
            }
            else
            {
                Console.Write("There was an error downloading the image: " + response);
            }
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
            Console.Clear();
        }

        private async Task<string[]> RetrieveAllPurchases()
        {
            try
            {
                await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.GetAllPurchases));
                await Send(user);

                byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
                byte[] listBytes = await networkDataHelper.ReceiveAsync(dataLength);
                string list = conversionHandler.ConvertBytesToString(listBytes);
                string[] products = list.Split(";");
                return products;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                Console.ReadKey();
            }
            
            return new string[0];
        }
        
        private async Task ReviewProduct(string [] product)
        {
            Console.WriteLine("Enter your Score from 1 to 5:");
            string score = Console.ReadLine();
            Console.WriteLine("Enter your Review:");
            string review = Console.ReadLine();

            try
            {
                await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.RateProduct));
                await Send(product[0]+"#"+product[5]+"#"+score+"#"+review+"#"+user);
            
                byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
                byte[] responseBytes = await networkDataHelper.ReceiveAsync(dataLength);
                string response = conversionHandler.ConvertBytesToString(responseBytes);

                if (response == "Success")
                {
                    Console.WriteLine("Product published successfully.");
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine(response);
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                }
            }
            catch (SocketException)
            {
                Console.Clear();
                Console.WriteLine("Server disconnected");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected Exception: " + ex.Message);
                Console.ReadKey();
            }
        }

        private async Task ExploreReviews(string[] product)
        {
            var reviews = await RetrieveProductReviews(product);

            byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
            int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
            byte[] responseBytes = await networkDataHelper.ReceiveAsync(dataLength);
            string response = conversionHandler.ConvertBytesToString(responseBytes);

            if (response == "Success")
            {
                if (!reviews.All(string.IsNullOrEmpty) && reviews.Length > 0)
                {
                    for (int i = 0; i < reviews.Length; i++)
                    {
                        string[] data = reviews[i].Split("#");
                        Console.WriteLine(
                            $"-> Score: {data[2]} | Review: {data[1]} | User: {data[0]}");
                    }
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("You have no products to view.");
                }
            }
            else
            {
                Console.WriteLine(response);
                Console.WriteLine("Press any key to continue");
                Console.ReadKey();
            }
        }

        private async Task<string[]> RetrieveProductReviews(string[] product)
        {
            try
            {
                await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.GetAllProductReviews));
                await Send(product[0]+"#"+product[5]);

                byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
                byte[] listBytes = await networkDataHelper.ReceiveAsync(dataLength);
                string list = conversionHandler.ConvertBytesToString(listBytes);
                string[] reviews = list.Split(";");
                return reviews;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                Console.ReadKey();
            }
            
            return new string[0];
        }

        private async Task SearchProducts(string productName)
        {
            try
            {
                Console.Clear();
                await networkDataHelper.SendAsync(conversionHandler.ConvertStringToBytes(Protocol.ProtocolCommands.SearchProducts));
                await Send(productName);

                byte[] lBytes = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                int dataLength = conversionHandler.ConvertBytesToInt(lBytes);
                byte[] responseBytes = await networkDataHelper.ReceiveAsync(dataLength);
                string response = conversionHandler.ConvertBytesToString(responseBytes);

                byte[] lb = await networkDataHelper.ReceiveAsync(Protocol.FixedDataSize);
                int dl = conversionHandler.ConvertBytesToInt(lb);
                byte[] rb = await networkDataHelper.ReceiveAsync(dl);
                string r = conversionHandler.ConvertBytesToString(rb);

                if (r == "Success")
                {
                    string[] products = response.Split(";");

                    if (products.Length > 0)
                    {
                        Console.WriteLine("Select a product to expand:");
                        for (int i = 0; i < products.Length; i++)
                        {
                            string[] data = products[i].Split("#");
                            Console.WriteLine($"{i + 1}. Name: {data[0]} | Description: {data[1]} | Stock: {data[2]} | Price: {data[3]}");
                        }

                        bool exit = false;
                        while (!exit)
                        {
                            var option = Console.ReadLine();

                            if (option == "exit")
                            {
                                exit = true;
                                break;
                            }

                            if (int.TryParse(option, out int selectedIndex) && selectedIndex >= 1 &&
                                selectedIndex <= products.Length)
                            {
                                var product = products[selectedIndex - 1].Split("#");
                                exit = true;
                                await ViewProduct(product);
                            }
                            else
                            {
                                Console.WriteLine("Invalid selection. Please select a valid product number or type 'exit' to quit.");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("No products match your search");
                        Console.WriteLine("Returning to previous window");
                        await ViewProductsMenu();
                    }
                }
                else
                {
                    Console.WriteLine(r);
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                }
            }
            catch (SocketException)
            {
                Console.Clear();
                Console.WriteLine("Server disconnected");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected Exception: " + ex.Message);
                Console.ReadKey();
            }
        }

        private async Task Send(string response)
        {
            byte[] responseBytes = conversionHandler.ConvertStringToBytes(response);
            int responseLength = responseBytes.Length;

            byte[] lengthBytes = conversionHandler.ConvertIntToBytes(responseLength);
            await networkDataHelper.SendAsync(lengthBytes);
            await networkDataHelper.SendAsync(responseBytes);
        }
    }
}